
package suport.Crear;

/**
 *
 * @author aleix
 */
public class CrearUsuari {
    
}
