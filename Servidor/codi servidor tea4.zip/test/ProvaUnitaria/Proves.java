/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package ProvaUnitaria;

import BBDD.SqlManager;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import objectes.Eines;
import objectes.Llibre;
import objectes.UsuariIntern;
import objectes.XifradorContrasenya;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author aleix
 */
public class Proves {
    SqlManager sqlManager = new SqlManager();
    Eines eines = new Eines();
    XifradorContrasenya xC = new XifradorContrasenya();
    
    public Proves() {
    }
      
    public UsuariIntern uExemple(){
        UsuariIntern usuari = new UsuariIntern();
        usuari.setUser("johndoe");
        usuari.setPass(xC.XifradorString("Visca"));
        usuari.setRol("usuario");
        usuari.setDataNaixement(new java.util.Date(1990, 5, 11));
        usuari.setNom("John");
        usuari.setPrimerCognom("Doe");
        usuari.setSegonCognom("Smith");
        usuari.setEmail("johndoe@example.com");
        usuari.setDataAlta(new Date());
        usuari.setMulta(0.0);
        usuari.setSuspensio(false);
        usuari.setImageData(eines.convertirABytes("imatges_usuaris/DefaultUser.png"));
        return usuari;
    }
    public Llibre llExemple(){
        Llibre llibre = new Llibre();
            llibre.setTitol("El código Da Vinci");
            llibre.setAutor("Dan Brown");
            llibre.setIsbn("9788401337031");
            llibre.setEditorial("Planeta");
            llibre.setAnyPublicacio(2003);
            llibre.setDescripcio("Una emocionante novela que combina elementos de misterio, historia y conspiración.");
            llibre.setSinopsi("El profesor de simbología religiosa Robert Langdon es llamado a resolver un misterioso asesinato en el Louvre y termina envuelto en una trama de intrigas y secretos que podrían cambiar la historia del cristianismo.");
            llibre.setPagines(454);
            llibre.setIdioma("Español");
            llibre.setExemplar(10);
            llibre.setNota("Excelente libro, muy recomendado.");
            llibre.setTitolOriginal("The Da Vinci Code");
            llibre.setTraductor("Alejandro Palomas");
            return llibre;
        
    }
  
    @Test
    public void testUsuari() {
        UsuariIntern u = uExemple();
        sqlManager.uIntern.crearUsuariExtens(u);
        assertTrue(sqlManager.uIntern.existeixNomUsuari(u.getUser()));
        assertTrue(sqlManager.uIntern.existeixNomUsuari(u.getUser()));
        assertEquals((sqlManager.uIntern.verificarUsuari(u.getUser(), u.getPass())),u.getRol());
        sqlManager.uIntern.eliminarUsuari(u.getUser());
        assertFalse(sqlManager.uIntern.existeixNomUsuari(u.getUser()));
    }
    
       @Test
    public void testLlibre() {
        try {
            Llibre ll = llExemple();
            sqlManager.llibres.crearLlibre(ll);
            String[] args = {null,null,ll.getIsbn(),null,null,null,null,null,null,null,null,null,null,null};
            List<Llibre> buscarLlibres = sqlManager.llibres.buscarLlibres(args);
            System.out.println(buscarLlibres.size());
            System.out.println(buscarLlibres.get(0).getId());
            assertEquals(buscarLlibres.get(0).getIsbn(),ll.getIsbn());
            ll.setAutor("Xavier Bosch");
            sqlManager.llibres.modificarLlibre(ll);
            assertEquals(sqlManager.llibres.buscarLlibreid(buscarLlibres.get(0).getId()).getAutor(),ll.getAutor());
            sqlManager.llibres.esborrarLlibre(ll);
            assertTrue(sqlManager.llibres.buscarLlibres(args).size()==0);
        } catch (SQLException ex) {
            Logger.getLogger(Proves.class.getName()).log(Level.SEVERE, null, ex);
        }

       
       
   }


    
    


    
}
